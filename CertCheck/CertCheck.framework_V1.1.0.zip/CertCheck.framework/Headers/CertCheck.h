//
//  CertCheck.h
//  CertCheck
//
//  Created by Harvey on 2019/8/22.
//  Copyright © 2019 姚作潘/Harvey. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CertCheck.
FOUNDATION_EXPORT double CertCheckVersionNumber;

//! Project version string for CertCheck.
FOUNDATION_EXPORT const unsigned char CertCheckVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CertCheck/PublicHeader.h>


