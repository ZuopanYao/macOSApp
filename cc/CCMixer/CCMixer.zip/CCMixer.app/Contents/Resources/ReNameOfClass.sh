#
# ReNameOfClass.swift
# CCMixer
#
# 批量修改类名脚本
#
# Created by 姚作潘/Harvey on 2019/03/02.
# Copyright © 2019 www.yaozuopan.top. All rights reserved
#

##########################################################################
## 传入参数
files=($1)
className=$2
newClassName=$3

##########################################################################
## 原规则
origin1="@class ${className};"
origin2="@interface ${className}"
origin3="@implementation ${className}"
origin4="\[${className} "
origin5="${className} \*"
origin6="${className}\*"
origin7=" : ${className}"
# 属性
origin8=") ${className} "
origin9=":${className}]"
origin10="${className}\.class"
origin11="(${className} "


## 新规则
new1="@class ${newClassName};"
new2="@interface ${newClassName}"
new3="@implementation ${newClassName}"
new4="\[${newClassName} "
new5="${newClassName} \*"
new6="${newClassName}\*"
new7=" : ${newClassName}"
# 属性
new8=") ${newClassName} "
new9=":${newClassName}]"
new10="${newClassName}\.class"
new11="(${newClassName} "

## 遍历文件应用新规则
for file in ${files[*]}
do

sed -i '' "s/$origin1/$new1/g;s/$origin2/$new2/g;s/$origin3/$new3/g;s/$origin4/$new4/g;s/$origin5/$new5/g;s/$origin6/$new6/g;s/$origin7/$new7/g;s/$origin8/$new8/g;s/$origin9/$new9/g;s/$origin10/$new10/g;s/$origin11/$new11/g" $file

done

echo 1
##########################################################################
