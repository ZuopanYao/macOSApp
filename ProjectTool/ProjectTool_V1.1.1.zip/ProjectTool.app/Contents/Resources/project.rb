require 'xcodeproj'
require 'fileutils'

root_path = $*[0]
productName = $*[1]

project_path = "#{root_path}/Demo/Demo.xcodeproj"
proj = Xcodeproj::Project.open(project_path)

app_target = proj.targets[0]
app_target.name = productName

files_path = File.open("#{root_path}/Demo/Code/file.txt","r").gets
file_group = files_path.split(';')

for item_group in file_group do
    
    file_array = item_group.split('=')
    file_dir = file_array[0]
    file_path_array = file_array[1].split(',')
    
    group = proj.main_group.find_subpath("Code/#{file_dir}", true)
    group.set_source_tree('SOURCE_ROOT')
    
    for item in file_path_array do
        
        # add file
        file_ref = group.new_reference(item)
        
        # for ObjectiveC
        result = item.include? ".m"
        if result
            
            # 添加到 Build Phases
            app_target.add_file_references([file_ref])
        end
        
        # for swift
        result = item.include? ".swift"
        if result
            
            # 添加到 Build Phases
            app_target.add_file_references([file_ref])
        end
    end
end
    
proj.save()

FileUtils.rm("#{root_path}/Demo/Code/file.txt")
    
root_new_path = "#{root_path}/#{productName}"
FileUtils.mv("#{root_path}/Demo", root_new_path)
    
FileUtils.mv("#{root_new_path}/Demo.xcodeproj", "#{root_new_path}/#{productName}.xcodeproj")
    
    
    #
    # ref_file = group.new_reference("#{file_path}/AppDelegate.swift")
    # app_target.source_build_phase.add_file_reference(ref_file)
    #
    # ref_file = group.new_reference("#{file_path}/ViewController.swift")
    # app_target.source_build_phase.add_file_reference(ref_file)
    
    
    #app_target.name = productName
    
    # config = app_target.build_configurations
    #
    # for element in app_target.build_configurations do
    #
    #   puts element.name
    #   puts element.build_settings['INFOPLIST_FILE'];
    #
    #   # for node in  element.build_settings do
    #   #   puts node
    #   # end
    #
    # end
    
    
    #proj.save()
    
    
    # app_target = proj.targets[0]
    # #proj.new_target(:application, productName, :ios, '9.0')
    #
    # app_target.name = 'MyName'
    #
    # proj.save(project_path)
    
    #
    # file_string = File.open("#{root_path}/shell/filePath.txt","r").gets
    # array_dir = file_string.split(';')
    #
    # array_file_dict = Hash.new()
    # for item in array_dir do
    #
    #   array_file = item.split('=')
    #
    #   key = array_file[0]
    #   value = array_file[1].split()
    #
    #   array_file_dict[key] = value
    # end
    #
    # # project
    
    # Xcodeproj::Project
    #  project = Xcodeproj::Project.open(project_path)
    #
    # # target
    # target = project.targets.first
    #
    #
    # keys = array_file_dict.keys
    # for key in keys do
    #
    # # group
    #   group = project.main_group.find_subpath("ios/#{key}", true)
    #   group.set_source_tree('SOURCE_ROOT')
    #   array_files = array_file_dict[key]
    #
    #   for item in array_files do
    #
    #     # add file
    #     file_ref = group.new_reference(item)
    #
    #     result = item.include? ".m"
    #     if result
    #       # 添加到 Build Phases
    #       target.add_file_references([file_ref])
    #     end
    #
    #   end
    # end
    #
    # # group.files.each do |item_file_ref|
    # #
    # #   result = item_file_ref.real_path.to_s.include? "UIColor+Hex"
    # #
    # #   if result
    # #
    # #   group.remove_reference(item_file_ref)
    # #   target.source_build_phase.remove_file_reference(item_file_ref)
    # #   end
    # # end
    #
    #
    #
    # # 保存
    # project.save
    #
    # puts "添加文件成功"
    
    
    
    
    

