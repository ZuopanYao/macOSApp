#!/usr/bin/python3.7
# -*- coding: UTF-8 -*-

import os
import re
import random
import sys

floder = str(sys.argv[1])
word_len = int(sys.argv[2])
word_value = sys.argv[3]

legal_files = []

for root, dirs, files in os.walk(floder):
    for f in files:
        (_, ext) = os.path.splitext(f)
        if ext in ['.m', '.mm', '.swift']:
            legal_files.append(root + '/' + f)

legal_words1 = []
legal_words2 = []
legal_words3 = []
legal_words4 = []
legal_words5 = []

regular1 = re.compile('[A-Z][a-z]{3,}')
regular2 = re.compile('[A-Z][a-z]{3,}[A-Z][a-z]{3,}')
regular3 = re.compile('[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}')
regular4 = re.compile('[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}')
regular5 = re.compile('[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}[A-Z][a-z]{3,}')

for path in legal_files:
    f = open(path, 'r')
    string = f.read()
    if '1' in word_value:
        legal_words1 += regular1.findall(string)
    
    if '2' in word_value:
        legal_words2 += regular2.findall(string)
    
    if '3' in word_value:
        legal_words3 += regular3.findall(string)
    
    if '4' in word_value:
        legal_words4 += regular4.findall(string)
    
    if '5' in word_value:
        legal_words5 += regular5.findall(string)

legal_words = list(set(legal_words1)) + list(set(legal_words2)) + list(set(legal_words3)) + list(set(legal_words4)) + list(set(legal_words5))
for index, word in enumerate(legal_words):
    frist = word[0:1]
    new_word = str.lower(frist) + word[1:]
    legal_words[index] = new_word

legal_words = list(filter(lambda item: len(item) > word_len, legal_words))
random.shuffle(legal_words)

value = ",".join(legal_words) + " [" + str(len(legal_words)) + "个]"
print(value)
